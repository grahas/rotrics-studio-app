# @untether/client

Node.js client for [untether](https://github.com/grahas/untether), which makes USB-serial
devices available over the network. It covers:

- discovery over mDNS (`_untether._tcp`, `_dexarm-link._tcp`) and the local status API.
- `LineConnection` for the newline-framed `line` adapter, with pairing, keepalive,
  control replies, reconnect and firmware updates (`flashFirmware`).
- `RawConnection` for `raw` byte pipes.

```js
const { discover, LineConnection } = require('@untether/client');

const [device] = await discover({ timeoutMs: 2000 });
const conn = await LineConnection.connect(device);
conn.on('line', console.log);
conn.send('M115');
```

Full API reference: [clients/node/README.md](https://github.com/grahas/untether/blob/main/clients/node/README.md).
Requires Node.js 18 or newer. License: MIT.
